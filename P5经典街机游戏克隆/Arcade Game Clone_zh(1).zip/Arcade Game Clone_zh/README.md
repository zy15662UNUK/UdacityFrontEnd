
前端纳米学位街机游戏克隆项目
===============================


## Clone && Run
- 下载并解压缩 `Arcade Game Clone_zh.zip` 文件
- 双击运行 `index.html` 文件

## Rules
- 玩家（player）可通过键盘的up、left、down、right键来控制玩家的上下左右移动，但不许超过Canvas范围
- 敌人（enemy）已随意速度、随意位置移动，可循环的出现的Canvas上
- 玩家在穿越石头的过程中，不许碰到敌人，若接触到敌人，则game over,玩家回到初始位置重新开始，当玩家经过石头到达河岸且中途不被敌人触碰到，则为胜利

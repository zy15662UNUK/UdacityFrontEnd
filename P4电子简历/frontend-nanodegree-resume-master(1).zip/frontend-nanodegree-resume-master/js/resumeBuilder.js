
/*
This is empty on purpose! Your code to build the resume will go here.
 */


var bio = {
  "name": "Jiahao Luo",
  "role": "Student",
  "skills": ["Programming on python, HTML, CSS, JavaScript","Boxing"],
  "welcomeMessage": "I am currently completing a BEng in Chemical Engineering at the University of Nottingham. The programme is a four-year 2+2 programme, with the first two years on Nottingham’s Ningbo, China campus, and the next two years on Nottingham UK campus. I am on target to comfortably achieve FIRST CLASS HONOURS, and have maintained high grades throughout my studies. My most recent year’s grade average is 81%, with 76% and 78% in previous 2 years, where 70% is a first-class grade.",
  "biopic": "",
  "contacts": {
    "mobile": "0044 07729797411",
    "email": "enyjl7@nottingham.ac.uk",
    "github": "zy15662UNUK",
    "location": "L005 Rutland hall, University of Nottingham, Nottingham, NG7 2QZ",
  }
};

var education = {
  "schools": [
    {"name" : "University of Nottingham, Ningbo, China",
    "location" : "Ningbo, China",
    "dates" : "Sep 2014 - June 2016",
    "degree": "bachelor",
    "url": "https://www.nottingham.edu.cn",
    "majors": "Chemical Engineering"
  },
    {"name" : "University of Nottingham",
    "location" : "Nottingham, UK ",
    "dates" : "Sep 2016 - May 2018",
    "degree": "bachelor",
    "url": "https://www.nottingham.ac.uk",
    "majors": "Chemical Engineering"
  }
],
 "onlineCourses": [
   {
     "name" : "Introduction to Computer Science and Programming Using Python",
     "school" : "MIT",
     "dates" : "2017.2-2017.4",
     "url": "https://www.edx.org/course/introduction-computer-science-mitx-6-00-1x-11"
   },
   {
     "name" : "Introduction to Computational Thinking and Data Science",
     "school" : "MIT",
     "dates" : "2017.4-2017.5",
     "url": "https://www.edx.org/course/introduction-computational-thinking-data-mitx-6-00-2x-6"
   },
   {
     "name" : "Front-End Web Developer Nanodegree",
     "school" : "Udacity",
     "dates" : "2017.10-till now",
     "url": "https://www.udacity.com/course/front-end-web-developer-nanodegree--nd001"
   }
 ],
};

var work = {
  "jobs": [
    {
      "employer": "Urban Environment Observation and Research Station, Ningbo, China",
      "title": "Research Assistant",
      "location": "Ningbo, China",
      "dates": "June 2016 – Aug 2016",
      "description": "Formulated enhanced adsorption performance of Kaolin clay and biochar for phosphate removal by impregnating material into sea water to load Ca2+ and Mg2+ onto material surface.\nAssisted post doctor research candidate to perform daily experiments; developed safe operating lab skills; performed literature research in databases"
    },
    {
      "employer": "University of Nottingham, Ningbo China",
      "title": "Laboratory Assistant",
      "location": "Ningbo, China",
      "dates": "June 2017 - Aug 2017",
      "description": "Applied a crawler application called “Octopus” to collect data online\nAssisted in building up a credit score system for a P2P website in construction industry\nTried to identify potential clients for a decoration company\nRecognized the importance of big data and programming skills",
    },
  ]
};

var projects = {
  "projects": [
    {
      "title": "mock-up-to-article",
      "dates": "2017.10",
      "description": "tb5ynyn",
      "images": "images\\fry.jpg"
    },
    {"title": "animal-trading-card",
    "dates": "2017.10",
    "description": "fregv4tb",
    "images": "images\\fry.jpg",
  },
    {"title": "design-mockup-portfolio",
    "dates": "2017.10",
    "description": "by5n6",
    "images": "images\\fry.jpg"
  },
  ],

};
bio.display = function() {
  var formattedName = HTMLheaderName.replace("%data%", bio.name);
  var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
  var formattedBioPic = HTMLbioPic.replace("\"%data%\"", "images\\fry.jpg");
  var formattedWelcomeMessage = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
  var formattedMobile = HTMLmobile.replace("%data%", bio.contacts.mobile);
  var formattedEmails = HTMLemail.replace("%data%", bio.contacts.email);
  var formattedGithub = HTMLgithub.replace("%data%", bio.contacts.github);
  var formattedLocation = HTMLlocation.replace("%data%", bio.contacts.location);
  $("#header").append(formattedName);
  $("#header").append(formattedRole);
  $("#header").append(formattedMobile);
  $("#header").append(formattedEmails);
  $("#header").append(formattedGithub);
  $("#header").append(formattedLocation);
  $(".clear-fix").append(formattedBioPic);
  $("#header").append(formattedWelcomeMessage);
  $("#header").append(HTMLskillsStart);
  for (var i = 0; i < bio.skills.length; i++){
    $("#skills-h3").append(HTMLskills.replace("%data%", bio.skills[i]));
  }
};
bio.display();

education.display = function() {
  var formattedSchoolName, formattedSchoolDegree, formattedSchoolDates, formattedSchoolLocation, formattedSchoolMajor;
  for(i = 0; i < education.schools.length; i++) {
    formattedSchoolName = HTMLschoolName.replace("%data%", education.schools[i].name);
    formattedSchoolDegree = HTMLschoolDegree.replace("%data%", education.schools[i].degree);
    formattedSchoolDates = HTMLschoolDates.replace("%data%", education.schools[i].dates);
    formattedSchoolLocation = HTMLschoolLocation.replace("%data%", education.schools[i].location);
    formattedSchoolMajor = HTMLschoolMajor.replace("%data%", education.schools[i].majors);
    $("#education").append(HTMLschoolStart);
    $(".education-entry:last").append(formattedSchoolName + formattedSchoolDegree);
    $(".education-entry:last").children("a").attr('href', education.schools[i].url);
    $(".education-entry:last").append(formattedSchoolDates);
    $(".education-entry:last").append(formattedSchoolLocation);
    $(".education-entry:last").append(formattedSchoolMajor);
  }
  $(".education-entry:last").append(HTMLonlineClasses);
  var formattedOnlineTitle, formattedOnlineSchool, formattedOnlineDates, formattedOnlineURL;
  for(i = 0; i < education.onlineCourses.length; i++) {
    formattedOnlineTitle = HTMLschoolName.replace("%data%", education.onlineCourses[i].name);
    formattedOnlineSchool = HTMLschoolDegree.replace("%data%", education.onlineCourses[i].school);
    formattedOnlineDates = HTMLschoolDates.replace("%data%", education.onlineCourses[i].dates);
    formattedOnlineURL = HTMLschoolLocation.replace("%data%", education.onlineCourses[i].url);
    $(".education-entry:last").append(formattedOnlineDates);
    $(".education-entry:last").append(formattedOnlineTitle + formattedOnlineSchool);
    $(".education-entry:last").children("a:last").attr('href', education.onlineCourses[i].url);
    // $(".education-entry:last").append(formattedOnlineURL);
  }

};
education.display();


work.display = function() { for (var job in work.jobs){
  $("#workExperience").append(HTMLworkStart);
  var formatWorkEmployer = HTMLworkEmployer.replace("%data%",work.jobs[job].employer);
  var formattedWorkTitle = HTMLworkTitle.replace("%data%",work.jobs[job].title);
  var formattedWorkDates = HTMLworkDates.replace("%data%",work.jobs[job].dates);
  var formattedWorkLocation = HTMLworkLocation.replace("%data%",work.jobs[job].location);
  var formattedWorkDescription = HTMLworkDescription.replace("%data%",work.jobs[job].description);
  $(".work-entry:last").append(formatWorkEmployer+formattedWorkTitle);
  $(".work-entry:last").append(formattedWorkDates);
  $(".work-entry:last").append(formattedWorkLocation);
  $(".work-entry:last").append(formattedWorkDescription);
}
};
work.display();

projects.display = function(){
  for (var i = 0; i <projects.projects.length; i++){
    var formattedProjectTitle = HTMLprojectTitle.replace("%data%",projects.projects[i].title);
    var formattedProjectDates = HTMLprojectDates.replace("%data%",projects.projects[i].dates);
    var formattedProjectDescription = HTMLprojectDescription.replace("%data%",projects.projects[i].description);
    var formattedProjectImage = HTMLprojectImage.replace("%data%",projects.projects[i].images);
    $("#projects").append(HTMLprojectStart);
    $(".project-entry:last").append(formattedProjectTitle);
    $(".project-entry:last").append(formattedProjectDates);
    $(".project-entry:last").append(formattedProjectDescription);
    $(".project-entry:last").append(formattedProjectImage);


  }
};
projects.display();
$("#mapDiv").append(googleMap);
$("#main").append(internationalizeButton);
